from django import forms
from .models import Poll


class PollForm(forms.Form):
    title = forms.CharField(max_length=50)
    description = forms.Textarea()
    slug = forms.SlugField()
    numberOfVoters = forms.IntegerField()
    timeOfBeg = forms.DateTimeField()
    timeOfEnd = forms.DateTimeField()

    def save(self):
        new_poll = Poll.objects.create(
            title = self.cleaned_data['title'],
            description = self.cleaned_data['description'],
            slug = self.cleaned_data['slug'],
            numberOfVoters = self.cleaned_data['numberOfVoters'],
            timeOfBeg = self.cleaned_data['timeOfBeg'],
            timeOfEnd = self.cleaned_data['timeOfEnd'],
        )
        return new_poll
